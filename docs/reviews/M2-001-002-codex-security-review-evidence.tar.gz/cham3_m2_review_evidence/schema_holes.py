import copy, importlib.util, json, sys
spec=importlib.util.spec_from_file_location('oracle',sys.argv[1]); o=importlib.util.module_from_spec(spec);spec.loader.exec_module(o)
x=json.load(open(sys.argv[2]));keys={k['label']:o.key_t(k['label']) for k in x['keys']};resolver=o.resolver_t(list(keys.values()))
vs={v['name']:v for v in x['valid']}
def payload(name):return o.verify(bytes.fromhex(vs[name]['envelope']),'commit',resolver)
gen=payload('commit_genesis'); signer=keys['user_1001_persistent']
# Existing lineage/package identity can change through an ordinary revision.
rev=copy.deepcopy(payload('commit_revision'));rev['subject']['package_identity']='deb:attacker:amd64';rev['subject']['executable_sha256']=b'\x42'*32
b,_=o.sign_commit(signer,rev)
o.admit_chain([bytes.fromhex(vs['commit_genesis']['envelope']),b],resolver)
print('ACCEPTED ordinary revision with substituted package/executable; no identity_transition')
# One grant, changed modes through two byte-valid temporary branches cannot model temporary network authority.
net=copy.deepcopy(gen);net['delta']={'add_grants':[],'remove_grant_ids':[],'network_mode':{'from':'offline','to':'direct'}};net['result_state']={'grants':[],'network_mode':'direct'}
b,_=o.sign_commit(signer,net);o.admit_chain([b],resolver)
print('ACCEPTED Direct genesis with zero grants and no network lifetime/grant id')
# Network restore target not constrained to referenced historical mode.
chain=[bytes.fromhex(v['envelope']) for v in x['valid'] if v['name'] in x['lineage']['commits']]
# lineage field shape inspected below

# Restore references Offline genesis but changes result to Direct.
r=copy.deepcopy(payload('commit_restore'));r['restore_reference']=bytes.fromhex(vs['commit_genesis']['object_id']);r['delta']['add_grants']=[];r['delta']['remove_grant_ids']=[];r['delta']['network_mode']={'from':'direct','to':'tor'}
base=payload('commit_revocation')['result_state'];r['result_state']=copy.deepcopy(base);r['result_state']['network_mode']='tor'
b,_=o.sign_commit(signer,r);o.admit_chain(chain[:6]+[b],resolver)
print('ACCEPTED restore referencing Offline snapshot but introducing Tor network mode')

# Construct a valid 65536-byte commit and measure the wrappers.
g=copy.deepcopy(gen);g['message']='';g['delta']={'add_grants':[],'remove_grant_ids':[]};g['result_state']={'grants':[],'network_mode':'offline'}
found=False
for n in range(1,65):
    grants=[o.make_grant('boundary '+str(i),'filesystem','r'*512,['read']) for i in range(n)]
    grants.sort(key=lambda item:item['grant_id']);g['delta']['add_grants']=grants;g['result_state']['grants']=grants
    size=len(o.build_envelope('commit',signer,o.encode(g),signature=b'\x00'*64))
    if not 64500 <= size <= 66560: continue
    for rlen in range(1,513):
        grants[-1]['resource']['resource_id']='r'*rlen;g['message']=''
        size=len(o.build_envelope('commit',signer,o.encode(g),signature=b'\x00'*64))
        padding=65536-size
        if not 0 <= padding <=1024: continue
        for trial in range(max(0,padding-5),min(1024,padding+5)+1):
            g['message']='m'*trial
            candidate=o.build_envelope('commit',signer,o.encode(g),signature=b'\x00'*64)
            if len(candidate)!=65536: continue
            b,_=o.sign_commit(signer,g);o.admit_chain([b],resolver)
            wrapped=o.encode({'op':'submit_signed','request_id':b'\x00'*16,'args':{'envelope':b}})
            record=o.encode({'seq':1,'time':o.Times[0],'kind':'commit_admitted','envelope':b})
            print('ACCEPTED boundary commit bytes=%d; IPC bytes=%d; journal record bytes=%d'%(len(b),len(wrapped),len(record)))
            found=True;break
        if found:break
    if found:break
assert found, 'no boundary vector constructed'

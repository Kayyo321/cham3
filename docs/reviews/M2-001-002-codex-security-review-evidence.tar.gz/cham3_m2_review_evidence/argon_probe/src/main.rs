#![forbid(unsafe_code)]
use argon2::{Algorithm, Argon2, Block, Params, Version};
fn main() {
    let params = Params::new(32, 3, 1, Some(32)).unwrap();
    let mut blocks = vec![Block::default(); params.block_count()];
    let mut output = [0u8;32];
    Argon2::new(Algorithm::Argon2id, Version::V0x13, params)
        .hash_password_into_with_memory(b"public synthetic password", b"public synthetic salt", &mut output, &mut blocks).unwrap();
    let nonzero = blocks.iter().any(|block| block.as_ref().iter().any(|word| *word != 0));
    assert!(nonzero);
    println!("CONFIRMED caller-supplied Argon2 workspace remains nonzero with zeroize feature enabled");
}

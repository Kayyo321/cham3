import hashlib, json, sys
import cbor2
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.backends.openssl.backend import backend
x=json.load(open(sys.argv[1]))
keys={bytes.fromhex(k['key_id']): bytes.fromhex(k['public_key']) for k in x['keys']}
aads={k:('cham3/'+v+'/v1').encode() for k,v in [('commit','ecr-commit'),('identity_enrollment','identity-enrollment'),('key_certificate','key-certificate'),('key_invalidation','key-invalidation')]}
for v in x['valid']:
    data=bytes.fromhex(v['envelope']); root=cbor2.loads(data)
    assert root.tag==18 and len(root.value)==4
    protected,unprotected,payload,signature=root.value
    header=cbor2.loads(protected); decoded=cbor2.loads(payload)
    assert cbor2.dumps(root,canonical=True)==data
    assert cbor2.dumps(header,canonical=True)==protected
    assert cbor2.dumps(decoded,canonical=True)==payload
    assert header[1]==-19 and unprotected=={}
    signed=cbor2.dumps(['Signature1',protected,aads[v['kind']],payload],canonical=True)
    pub=Ed25519PublicKey.from_public_bytes(keys[header[4]])
    pub.verify(signature,signed)
    try: pub.verify(signature,signed+b'\x00')
    except InvalidSignature: pass
    else: raise AssertionError('altered signing preimage accepted')
    assert hashlib.sha256(data).hexdigest()==v['object_id']
    if v['kind']=='commit':
        s=decoded['subject']; expected=hashlib.sha256(b'cham3/lineage/v1\x00'+cbor2.dumps([s['owner_user_id'],s['app_id'],s['installation_id']],canonical=True)).digest()
        assert decoded['lineage_id']==expected
    print('PASS',v['name'])
print('PASS 17 canonical envelopes, signatures, hashes; 17 changed-preimage rejections')
print('ENV cryptography/OpenSSL',backend.openssl_version_text())
